---
title: 'Carlos dos Santos'
button: 'About us'
weight: 2
---

Tenho mais de 20 anos de experiência no desenvolvimento de softwares. Sou certificado Microsoft MCP, Microsoft MVP C#. Sou palestrante em diversos eventos Microsoft, tenho diversos artigos publicados em revistas e participo dos fóruns do MSDN.

Ministro treinamentos e consultorias in-company para evolução tecnológica de aplicações, melhora de performance e Cloud.

As opiniões colocadas neste blog são minhas e pessoais e não expressam necessariamente as opiniões de meus empregadores, parceiros e amigos. Da mesma forma, os comentários feitos por leitores do blog não expressam a minha opinião.

Alguns projetos OpenSource que participo:

* https://github.com/boletonet
* https://github.com/htmltopdfcore
